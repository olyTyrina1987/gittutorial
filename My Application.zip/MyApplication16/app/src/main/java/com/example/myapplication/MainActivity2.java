package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import java.io.IOException;

public class MainActivity2 extends AppCompatActivity {


  
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }

    public void clickButton333 (View v) throws IOException {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    
    public void clickButton334 (View v) throws IOException {
        EditText et = (EditText)findViewById(R.id.edit_text1);
        String EditText1 = et.getText().toString();
        int EditText11 = new Integer(EditText1).intValue();
        
        
         if (EditText11 == 12345)
         {
             Toast.makeText(getApplicationContext(), "Редатор доступен!", Toast.LENGTH_SHORT).show();
             Intent intent = new Intent(this, MainActivity3.class);
             startActivity(intent);
         }
        else 
        {
            Toast.makeText(getApplicationContext(), "Пароль введен неверный!", Toast.LENGTH_SHORT).show();
        }    
    }


    public void clickButton3345 (View v) throws IOException {
        Intent intent = new Intent(this, MainActivity4.class);
        startActivity(intent);
    }
 
}