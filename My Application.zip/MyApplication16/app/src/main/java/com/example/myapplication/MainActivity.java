package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    private final static String FILE_NAME = "input2.txt";
    private final static String FILE_NAME2 = "res.txt";
    
    String[] countries = {"1", "2", "3", "4"};
    
    int sum, sum1, sum2, sum3, sum4, sum5, sum6, sum7, sum8, sum9, sum10;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
       // setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);

        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, countries);
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Применяем адаптер к элементу spinner
        spinner.setAdapter(adapter);
   
    }
    private File getExternalPath() {
        return new File(getExternalFilesDir(null), FILE_NAME);
    }
    private File getExternalPath2() {
        return new File(getExternalFilesDir(null), FILE_NAME2);
    }
   

    public void clickButton33(View view) {
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);
        

        File file = getExternalPath();
        File file2 = getExternalPath2();

        if (!file2.exists()) return;
        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);
           
            String b1 = new String(bytes); 

                                   
            sum1 = 0;
            String[] array1 = b1.split(";"); 
            
            for (int i = 0; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[0]);
                textView2.setText("1. " + array1[1]);
                textView3.setText("2. " + array1[2]);
                textView4.setText("3. " + array1[3]);
                textView5.setText("4. " + array1[4]); 

                String selected = spinner.getSelectedItem().toString();

                if (array1[5].equals(selected)) {
                   // Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum1 = 1;
                } else {
                  //  Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                  //  toast.show();
                    sum1 = 0;

                }
            }
            
        } catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }   

       new CountDownTimer(300000, 1000) {

       public void onTick(long millisUntilFinished) {
            textView.setText("Таймер: " + millisUntilFinished / 1000);
        }

        public void onFinish() {
            textView.setText("Время истекло!");
        }
    }.start();
    }
    
//кнопка 1
    public void clickButton67(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] b = new byte[fin.available()];
            fin.read(b);

            String b1 = new String(b);
 
            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 6; i < array1.length; i++) {
                    textView1.setText("Вопрос: " + array1[6]);
                    textView2.setText("1. " + array1[7]);
                    textView3.setText("2. " + array1[8]);
                    textView4.setText("3. " + array1[9]);
                    textView5.setText("4. " + array1[10]); 


                  //  textView.setText(array1[11]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                    String selected = spinner.getSelectedItem().toString();

                    if (array1[11].equals(selected)) {
                       // Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                        sum2 = 1;
                    } else {
                       // Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                        //toast.show();
                        sum2 = 0;
                    }
                   // textView.setText(sum2); // балл 
                }
            }


        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }}

        
        //кнопка 2
        public void clickButton661(View view) {  // адаптер
            TextView textView = findViewById(R.id.textView);
            TextView textView1 = findViewById(R.id.textview1);
            TextView textView2 = findViewById(R.id.textview2);
            TextView textView3 = findViewById(R.id.textview3);
            TextView textView4 = findViewById(R.id.textview4);
            TextView textView5 = findViewById(R.id.textView5);
            TextView textView20 = findViewById(R.id.textView20);
            Spinner spinner = findViewById(R.id.spinner);


            File file = getExternalPath();

            // если файл не существует, выход из метода
            if (!file.exists()) return;

            try (FileInputStream fin = new FileInputStream(file)) {
                byte[] bytes = new byte[fin.available()];
                fin.read(bytes);

                String b1 = new String(bytes);


                sum1 = 0;
                String[] array1 = b1.split(";");
                for (int i = 12; i < array1.length; i++) {
                    textView1.setText(array1[12]);
                    textView2.setText(array1[13]);
                    textView3.setText(array1[14]);
                    textView4.setText(array1[15]);
                    textView5.setText(array1[16]);
                    //textView.setText(array1[5]);
                    // for (int j = 0; i < countries.length; j++) {
                    // if (array1[5].equals(countries[i])) {
                    // if (array1[5].equals(countries[i])) {


                  //  textView.setText(array1[17]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                    String selected = spinner.getSelectedItem().toString();

                    if (array1[17].equals(selected)) {
                       // Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                        sum3 = 1;
                    } else {
                      //  Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                      // toast.show();
                        sum3 = 0;
                    }
                   // textView.setText(sum3); // балл 
                }
            }


            catch (IOException ex) {

                Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        
        
// кнопка 3
    public void clickButton66(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            
            for (int i = 18; i < array1.length; i++) {
                    textView1.setText("Вопрос: " + array1[18]);
                    textView2.setText("1. " + array1[19]);
                    textView3.setText("2. " + array1[20]);
                    textView4.setText("3. " + array1[21]);
                    textView5.setText("4.: " + array1[22]);
                    //textView.setText(array1[5]);
                    // for (int j = 0; i < countries.length; j++) {
                    // if (array1[5].equals(countries[i])) {
                    // if (array1[5].equals(countries[i])) {


                   // textView.setText(array1[23]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                    String selected = spinner.getSelectedItem().toString();

                    if (array1[23].equals(selected)) {
                       // Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                        sum4 = 1;
                    } else {
                       // Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                      // toast.show();
                        sum4 = 0;
                    }
                    //textView.setText(sum4); // балл 
                }
            }


        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    
    //кнопка 4
    public void clickButton77(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 24; i < array1.length; i++) {
                    textView1.setText("Вопрос: " + array1[24]);
                    textView2.setText("1. " + array1[25]);
                    textView3.setText("2. " + array1[26]);
                    textView4.setText("3. " + array1[27]);
                    textView5.setText("4. " + array1[28]); 
                 //   textView.setText(array1[29]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                    String selected = spinner.getSelectedItem().toString();

                    if (array1[29].equals(selected)) {
                      //  Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                        sum5 = 1;
                    } else {
                      // Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                       // toast.show();
                        sum5 = 0;
                    }
                    //textView.setText(sum5); // балл 
                }
            }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    //кнопка 5
    public void clickButton610(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 30; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[30]);
                textView2.setText("1. " + array1[31]);
                textView3.setText("2. " + array1[32]);
                textView4.setText("3. " + array1[33]);
                textView5.setText("4. " + array1[34]);
                //textView.setText(array1[5]);
                // for (int j = 0; i < countries.length; j++) {
                // if (array1[5].equals(countries[i])) {
                // if (array1[5].equals(countries[i])) {


           //     textView.setText(array1[35]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                String selected = spinner.getSelectedItem().toString();

                if (array1[35].equals(selected)) {
                 //   Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum5 = 1;
                } else {
                   // Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                   // toast.show();
                    sum5 = 0;
                }
                //textView.setText(sum5); // балл 
            }
        }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


//кнопка 6
    public void clickButton660(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 36; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[36]);
                textView2.setText("1. " + array1[37]);
                textView3.setText("2. " + array1[38]);
                textView4.setText("3. " + array1[39]);
                textView5.setText("4. " + array1[40]);
                //textView.setText(array1[5]);
                // for (int j = 0; i < countries.length; j++) {
                // if (array1[5].equals(countries[i])) {
                // if (array1[5].equals(countries[i])) {


              //  textView.setText(array1[41]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                String selected = spinner.getSelectedItem().toString();

                if (array1[41].equals(selected)) {
                    Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum5 = 1;
                } else {
                    Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                    toast.show();
                    sum5 = 0;
                }
                //textView.setText(sum5); // балл 
            }
        }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    //кнопка 7
    public void clickButton99(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 42; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[42]);
                textView2.setText("1. " + array1[43]);
                textView3.setText("2. " + array1[44]);
                textView4.setText("3. " + array1[45]);
                textView5.setText("4. " + array1[46]);
                //textView.setText(array1[5]);
                // for (int j = 0; i < countries.length; j++) {
                // if (array1[5].equals(countries[i])) {
                // if (array1[5].equals(countries[i])) {


                //textView.setText(array1[47]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                String selected = spinner.getSelectedItem().toString();

                if (array1[47].equals(selected)) {
                    //Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum5 = 1;
                } else {
                 //  Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                  //  toast.show();
                    sum5 = 0;
                }
                //textView.setText(sum5); // балл 
            }
        }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }

//кнопка 8
    public void clickButton10(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 48; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[48]);
                textView2.setText("1. " + array1[49]);
                textView3.setText("2. " + array1[50]);
                textView4.setText("3. " + array1[51]);
                textView5.setText("4. " + array1[52]);
                //textView.setText(array1[5]);
                // for (int j = 0; i < countries.length; j++) {
                // if (array1[5].equals(countries[i])) {
                // if (array1[5].equals(countries[i])) {


              //  textView.setText(array1[53]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                String selected = spinner.getSelectedItem().toString();

                if (array1[53].equals(selected)) {
                 //   Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum5 = 1;
                } else {
                  //  Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                  //  toast.show();
                    sum5 = 0;
                }
                //textView.setText(sum5); // балл 
            }
        }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    //кнопка 9
    public void clickButton110(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 54; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[54]);
                textView2.setText("1. " + array1[55]);
                textView3.setText("2. " + array1[56]);
                textView4.setText("3. " + array1[57]);
                textView5.setText("4. " + array1[58]);
                //textView.setText(array1[5]);
                // for (int j = 0; i < countries.length; j++) {
                // if (array1[5].equals(countries[i])) {
                // if (array1[5].equals(countries[i])) {


               // textView.setText(array1[59]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                String selected = spinner.getSelectedItem().toString();

                if (array1[59].equals(selected)) {
                    //Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum5 = 1;
                } else {
                    //Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                   // toast.show();
                    sum5 = 0;
                }
                //textView.setText(sum5); // балл 
            }
        }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }


    //кнопка 10
    public void clickButton120(View view) {  // адаптер
        TextView textView = findViewById(R.id.textView);
        TextView textView1 = findViewById(R.id.textview1);
        TextView textView2 = findViewById(R.id.textview2);
        TextView textView3 = findViewById(R.id.textview3);
        TextView textView4 = findViewById(R.id.textview4);
        TextView textView5 = findViewById(R.id.textView5);
        TextView textView20 = findViewById(R.id.textView20);
        Spinner spinner = findViewById(R.id.spinner);


        File file = getExternalPath();

        // если файл не существует, выход из метода
        if (!file.exists()) return;

        try (FileInputStream fin = new FileInputStream(file)) {
            byte[] bytes = new byte[fin.available()];
            fin.read(bytes);

            String b1 = new String(bytes);


            sum1 = 0;
            String[] array1 = b1.split(";");
            for (int i = 59; i < array1.length; i++) {
                textView1.setText("Вопрос: " + array1[59]);
                textView2.setText("1. " + array1[60]);
                textView3.setText("2. " + array1[61]);
                textView4.setText("3. " + array1[62]);
                textView5.setText("4. " + array1[63]);
                //textView.setText(array1[5]);
                // for (int j = 0; i < countries.length; j++) {
                // if (array1[5].equals(countries[i])) {
                // if (array1[5].equals(countries[i])) {


               // textView.setText(array1[64]);
                           
                        /*   Toast toast = Toast.makeText(this, "Hello Android!",Toast.LENGTH_LONG);
                           toast.show();*/
                String selected = spinner.getSelectedItem().toString();

                if (array1[64].equals(selected)) {
                   // Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
                    sum5 = 1;
                } else {
                   // Toast toast = Toast.makeText(this, "Не верно!", Toast.LENGTH_LONG);
                  // toast.show();
                    sum5 = 0;
                }
                //textView.setText(sum5); // балл 
            }
        }
        catch (IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    public void clickButton6600(View view) 
        {  
            TextView textView = findViewById(R.id.textView);
            TextView textView1 = findViewById(R.id.textview1);
            TextView textView2 = findViewById(R.id.textview2);
            TextView textView3 = findViewById(R.id.textview3);
            TextView textView4 = findViewById(R.id.textview4);
            TextView textView5 = findViewById(R.id.textView5);
            TextView textView20 = findViewById(R.id.textView20);
            Spinner spinner = findViewById(R.id.spinner);
            sum = sum1+sum2 +sum3+sum3+sum4+sum5+sum6+sum7+sum8+sum9+sum10; 
            ((TextView) findViewById(R.id.textView20)).setText(sum + "0 %");

        }
    public void clickButton3300 (View v) throws IOException {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

        public void clickButton330 (View v) throws IOException {   
            Intent email = new Intent(Intent.ACTION_SEND);
 //Указываем получателя
            email.putExtra(Intent.EXTRA_EMAIL, new String[]{"oly1987@bk.ru"});
//Устанавливаем Тему сообщения
            email.putExtra(Intent.EXTRA_SUBJECT, "Тестриование");
//Устанавливаем само сообщение
            email.putExtra(Intent.EXTRA_TEXT, sum);
//тип отправляемого сообщения
            email.setType("message/rfc822");
//Вызываем intent выбора клиента для отправки сообщения
            startActivity(Intent.createChooser(email, "Выберите email клиент :"));
            
    }


    public void clickButton1334 (View v) throws IOException {

        try(FileOutputStream fos = new FileOutputStream(getExternalPath2())) {
            EditText textBox1 = findViewById(R.id.editor);
            TextView textView20 = findViewById(R.id.textView20); 
            String p1 = "___";
            
            String text = textBox1.getText().toString();
            fos.write(text.getBytes());
            
            String text2 = textView20.getText().toString();
            fos.write(text.getBytes());
 
            fos.write(p1.getBytes());
            
            fos.write(text2.getBytes());
            Toast.makeText(this, "Файл сохранен", Toast.LENGTH_SHORT).show();
        }
        catch(IOException ex) {
            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }    
} 
   
    
}


       